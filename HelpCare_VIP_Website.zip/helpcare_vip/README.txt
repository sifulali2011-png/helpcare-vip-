HelpCare VIP — Website template

Files:
- index.html: Complete responsive front-end template.

Before using it for real support requests:
1. Open index.html and find SUPPORT_API_URL in the final script.
2. Set it to your own HTTPS backend endpoint.
3. Keep Telegram bot tokens and other secrets on the server only, never in this HTML file.
4. Configure the backend to validate input, rate-limit requests, avoid logging sensitive data, and send only necessary support details to your support inbox.
5. Publish a privacy notice appropriate to your use.

The form intentionally does not request account passwords, OTPs, PINs, or full card details.
The form will show a setup message until SUPPORT_API_URL is configured.
